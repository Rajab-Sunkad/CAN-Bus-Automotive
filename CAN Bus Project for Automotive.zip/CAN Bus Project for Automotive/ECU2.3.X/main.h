#ifndef MAIN_H
#define MAIN_H

void intit_config();

#endif
