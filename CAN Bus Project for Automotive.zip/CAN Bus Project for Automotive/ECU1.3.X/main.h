#ifndef MAIN_H
#define MAIN_H

void init_config();


#endif